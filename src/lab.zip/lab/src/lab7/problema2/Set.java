package lab7.problema2;

public interface Set {
}
