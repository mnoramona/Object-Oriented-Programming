package lab5.problema4;

public class MARSHMALLOW_MAN_Warrior {

}
