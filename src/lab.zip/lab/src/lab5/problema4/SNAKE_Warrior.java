package lab5.problema4;

public class SNAKE_Warrior {
}
