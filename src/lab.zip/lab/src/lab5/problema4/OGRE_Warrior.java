package lab5.problema4;

public class OGRE_Warrior {
}
