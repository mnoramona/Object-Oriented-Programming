package lab5.problema3;

class ExceptieNumarNegativ extends Exception {
    public ExceptieNumarNegativ(){
        super("Numarul introdus este negativ!");
    }
}
