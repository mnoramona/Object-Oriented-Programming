//package lab3;
//
//class MyQueue {
//    private static final int Infinit = 9500;
//    private MyArray arr;
//    private int primul, ultimul, numar;
//
//    public MyQueue(){
//        arr = new MyArray(7);
//        this.primul = 0;
//        this.ultimul = 0;
//        this.numar = 0;
//    }
//
//    int getSize(){
//
//    }
//}
